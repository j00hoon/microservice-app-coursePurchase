package com.sb.springbootmicroserviceapps.springbootmicroservice2purchase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicroservice2PurchaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicroservice2PurchaseApplication.class, args);
	}

}
