package com.sb.springbootmicroserviceapps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroserviceAppsApplicationTests {

	@Test
	void contextLoads() {
	}

}
