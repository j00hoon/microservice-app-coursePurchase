package com.sb.springbootmicroserviceapps.springbootmicroservice4eureka.com.sb.springbootmicroserviceapps.springbootmicroservice4eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {

	@Test
	void contextLoads() {
	}

}
